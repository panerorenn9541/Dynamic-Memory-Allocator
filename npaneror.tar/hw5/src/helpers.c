#include "helpers.h"

/* Helper function definitions go here */

int FirstFlag = 1;
int IncCounter = 0;

int first_call()
{
	if(FirstFlag == 1)
	{
		FirstFlag = 0;
		return 1;
	}
	else
	{
		FirstFlag = 0;
		return FirstFlag;
	}
}

int payOffSize(int sz)
{
	if(sz%16 != 0)
	{
		return sz+(16-(sz%16));
	}
	else
	{
		return sz;
	}
}

void inc_counter()
{
	IncCounter++;
}

int get_counter()
{
	return IncCounter;
}

void my_mem_copy(void* sou, void* des, int sz)
{
	int i = 0;
	char* csou = (char*)sou;
	char* cdes = (char*)des;

	for(i = 0; i<sz; i++)
	{
		*(cdes+i) = *(csou+i);
	}
}


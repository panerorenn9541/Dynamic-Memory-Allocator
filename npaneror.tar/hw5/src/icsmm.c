/**
 * Do not submit your assignment with a main function in this file.
 * If you submit with a main function in this file, you will get a zero.
 * If you want to make helper functions, put them in helpers.c
 */
#include "icsmm.h"
#include "helpers.h"
#include <stdio.h>
#include <stdlib.h>

#include <errno.h>

ics_free_header *freelist_head = NULL;
ics_free_header *freelist_next = NULL;

void *ics_malloc(size_t size) 
{
	int fit_flag = 1;
	if(freelist_next == NULL)
	{
		if(1 == first_call())
		{
			uint64_t* start = (uint64_t*)ics_inc_brk();
			inc_counter();
                        ics_header* pro = (ics_header*) start;
                        pro->requested_size = 0;
                        pro->unused = 0xaaaaaaaa;
                        pro->block_size = 9;

			void* v_epi = ics_get_brk()-8;
			ics_header* epi = (ics_header*) v_epi;
			epi->requested_size = 0;
			epi->unused = 0xaaaaaaaa;
			epi->block_size = 9;

			uint64_t* v_freelist_head = start+1;
			freelist_head = (ics_free_header*) v_freelist_head;
			freelist_head->header.block_size = 4080;
			freelist_head->header.unused = 0xaaaaaaaa;
			freelist_head->header.requested_size = 0;
			freelist_head->next = NULL;
			freelist_head->prev = NULL;
			freelist_next = freelist_head;
			
			void* v_freelist_footer = ics_get_brk()-16;
			ics_footer* freelist_footer = (ics_footer*) v_freelist_footer;
			freelist_footer->block_size = freelist_head->header.block_size;
			freelist_footer->unused = 0xffffffffffff;
		}
	}
	if(0 == size)
	{
		errno = EINVAL;
		return NULL;
	}
	if(16352 < size)
	{
		errno = ENOMEM;
		return NULL;
	}
	if(freelist_next != NULL && payOffSize(size)+16 > freelist_next->header.block_size)
	{
		fit_flag = 0;
		ics_free_header* nex = freelist_next;
		while(nex->next != NULL)
		{
			nex = nex->next;
			if(nex->header.block_size >= payOffSize(size))
			{
				freelist_next = nex;
				fit_flag = 1;
				break;
			}
		}
		if(fit_flag != 1)
		{
			nex = freelist_head;
			while(nex->next != freelist_next && nex->next != NULL)
			{	
				if(nex->header.block_size >= payOffSize(size))
				{
					freelist_next = nex;
					fit_flag = 1;
					break;
				}
				nex = nex->next;
			}
			if(fit_flag != 1)
			{
				if(nex->header.block_size >= payOffSize(size))
				{
					freelist_next = nex;
					fit_flag = 1;
				}
			}
		}	
	}
	if (freelist_next == NULL)
	{
		fit_flag = 0;
	}
	int inc_count = 0;
	while(fit_flag != 1)
	{
		inc_count++;
		if(inc_count >= 5)
		{
			errno = ENOMEM;
			return NULL;
		}
		uint64_t* new_start = (uint64_t*)ics_inc_brk();
		inc_counter();
		uint64_t* v_prev_footer = new_start-2;
		ics_footer* prev_footer = (ics_footer*) v_prev_footer;
		int blk = prev_footer->block_size;
		
		if(blk%2 == 1)
		{
			ics_free_header* new_header = (ics_free_header*) new_start;
			new_header->header.block_size = 4088;
			new_header->header.unused = 0xaaaaaaaa;
			new_header->header.requested_size = 0;
			new_header->prev = NULL;
			new_header->next = freelist_head;
			if(freelist_head == NULL)
			{
				freelist_head = new_header;
			}
			freelist_next = new_header;
		}
		else
		{
			void* v1_prev_footer = (void*)v_prev_footer;
			void* v_prev_header = (void*) v1_prev_footer-blk+8;
			ics_free_header* prev_header = (ics_free_header*) v_prev_header;
			prev_header->header.block_size = prev_header->header.block_size+4096;
			freelist_next = prev_header;
		}

		void* v_epi = ics_get_brk()-8;
		ics_header* epi = (ics_header*) v_epi;
		epi->requested_size = 0;
		epi->unused = 0xaaaaaaaa;
		epi->block_size = 8;
			
		void* v_freelist_footer = ics_get_brk()-16;
		ics_footer* freelist_footer = (ics_footer*) v_freelist_footer;
		freelist_footer->block_size = freelist_next->header.block_size;
		freelist_footer->unused = 0xffffffffffff;
		
		if(payOffSize(size) <= freelist_footer->block_size)
		{
			fit_flag = 1;
			break;
		}
	}

	int old_free_size = freelist_next->header.block_size;

	ics_free_header* old_next = freelist_next;

	if(old_free_size != payOffSize(size)+16 && old_free_size-(payOffSize(size)+16) < 32)
        {
		ics_header* new_header = (ics_header*)freelist_next;
		new_header->block_size = old_free_size+1;	
		new_header->unused = 0xaaaaaaaa;
		new_header->requested_size = size;
		
		void* v_foot = (void*) new_header;
		v_foot = v_foot+(old_free_size-8);
		ics_footer* foot = (ics_footer*) v_foot;
		foot->block_size = old_free_size+1;
		foot->unused = 0xffffffffffff;

		freelist_next = freelist_next->next;
		if(freelist_next == NULL)
		{
			freelist_head = NULL;
		}
		
		return (void*)new_header+8; 
        }
	
	ics_free_header* old_loc = freelist_next->next;

	ics_header* new_header = (ics_header*)freelist_next;
	int payloadOff = payOffSize(size);
	int block_size = payloadOff+16;
	new_header->block_size = block_size+1;
	new_header->unused = 0xaaaaaaaa;
	new_header->requested_size = size;

	void* v_foot = (void*) new_header;
	v_foot = v_foot+(block_size-8);
	ics_footer* foot = (ics_footer*)v_foot;
	foot->block_size = block_size+1;
	foot->unused = 0xffffffffffff;

	if(old_free_size == payOffSize(size)+16)
        {
		if(freelist_head->next == NULL&& freelist_next->prev == NULL 
			&& freelist_next->next == NULL)
		{
                	freelist_head = NULL;
                	freelist_next = NULL;
               		return (void*)new_header+8;
		}
		if(freelist_next->next != NULL)
		{
			freelist_next->next->prev = freelist_next->prev;
		}
		if(freelist_next->prev != NULL)
		{
			freelist_next->prev->next = freelist_next->next;
		}
		if(freelist_next == freelist_head)
		{
			if(freelist_next->next != NULL)
			{
				freelist_next = freelist_next->next;
				freelist_head = freelist_next;
			}
			else
			{
				freelist_next = NULL;
				freelist_head = NULL;
			}
		}
		else
		{
			freelist_next = freelist_head;
		}
               	return (void*)new_header+8;
        }
	void* v_fnext = (void*) foot+8;
	freelist_next = (ics_free_header*) v_fnext;
	freelist_next->header.block_size = old_free_size - block_size;
	freelist_next->header.unused = 0xaaaaaaaa;
	freelist_next->header.requested_size = 0;

	if(old_next == freelist_head)
        {
		if(freelist_head->next == NULL)
		{
			freelist_next->next = NULL;
			freelist_next->prev = NULL;
			freelist_head = freelist_next;
		}
		else
		{
			freelist_head = freelist_next;
			freelist_head->next = old_loc;
			freelist_head->prev = NULL;
			freelist_head->next->prev = freelist_head;

			void* v_new_header = (void*) new_header;
			void* v_split_footer = v_new_header+old_free_size-8;
			ics_footer* split_footer = (ics_footer*) v_split_footer;
			split_footer->block_size = old_free_size-block_size;
			split_footer->unused = 0xffffffffffff;

		}
        }
	else
	{
		freelist_head->next = old_loc;
		freelist_head->prev = freelist_next;
		freelist_next->next = freelist_head;
		freelist_next->prev = NULL;
		freelist_head = freelist_next;
		while(freelist_next->next != NULL)
		{
			freelist_next = freelist_next->next;
		}

		void* v_new_header = (void*) new_header;
		void* v_split_footer = v_new_header+old_free_size-8;
		ics_footer* split_footer = (ics_footer*) v_split_footer;
		split_footer->block_size = old_free_size-block_size;
		split_footer->unused = 0xffffffffffff;
	}
	
	void* v_freelist_footer = ics_get_brk()-16;
	ics_footer* freelist_footer = (ics_footer*)v_freelist_footer;
	freelist_footer->block_size = old_free_size-block_size;
	freelist_footer->unused = 0xffffffffffff;
	
	return (void*)new_header+8; 
}

void *ics_realloc(void *ptr, size_t size)
{
	if(size == 0)
	{
		if(ics_free(ptr) == -1)
		{
			errno = EINVAL;
			return NULL;
		}
		else
		{
			return NULL;
		}
	}


	void* new_ptr = ics_malloc(size);
	if(new_ptr == NULL)
	{
		errno = ENOMEM;
		return NULL;
	}
	
	my_mem_copy(ptr, new_ptr, size);

	if(ics_free(ptr) == -1)
	{
		errno = EINVAL;
		return NULL;
	}

	return new_ptr;
}

int ics_free(void *ptr) 
{
	void* v_ptr_head = ptr-8;

	int num_pages = get_counter();
	if(ptr+32 > ics_get_brk())
	{
		errno = EINVAL;
		return -1;
	}
	
	void* start = ics_get_brk()-(num_pages*4096);
	if(v_ptr_head < start)
	{
		errno = EINVAL;
		return -1;
	}
		
	ics_free_header* ptr_head = (ics_free_header*) v_ptr_head;
	if(ptr_head->header.unused != 0xaaaaaaaa)
	{
		errno = EINVAL;
		return -1;
	}
	
	if(ptr_head->header.block_size%2 == 0)
	{
		errno = EINVAL;
		return -1;
	}

	void* v_ptr_foot = v_ptr_head+(ptr_head->header.block_size)-9;
	ics_footer* ptr_foot = (ics_footer*) v_ptr_foot;
	if(ptr_foot->unused != 0xffffffffffff)
	{
		errno = EINVAL;
		return -1;
	}

	if(ptr_head->header.block_size != ptr_foot->block_size)
	{
		errno = EINVAL;
		return -1;
	}

	if(ptr_head->header.block_size < ptr_head->header.requested_size)
	{
		errno = EINVAL;
		return -1;
	}

	if(((ptr_head->header.block_size%2) == 0) || ((ptr_foot->block_size%2) == 0))
	{
		errno = EINVAL;
		return -1;
	}

	int coal_bef_flag = 0;
	int coal_aft_flag = 0;

	void* v_prev_foot = v_ptr_head-8;
	ics_footer* prev_foot = (ics_footer*) v_prev_foot;
	if(prev_foot->block_size%2 == 0)
	{
		coal_bef_flag = 1;
		void* v_prev_head = v_prev_foot-(prev_foot->block_size)+8;
		ics_free_header* prev_head = (ics_free_header*) v_prev_head;
		int prev_block_size = prev_head->header.block_size;

		if(prev_head->next != NULL)
		{
			prev_head->next->prev = prev_head->prev;
		}
		if(prev_head->prev != NULL)
		{
			prev_head->prev->next = prev_head->next;
		}
		prev_head->header.block_size = prev_block_size+ptr_head->header.block_size-1;
		prev_head->next = freelist_head;
		prev_head->prev = NULL;
		freelist_head->prev = ptr_head;
		freelist_head = prev_head;

		ptr_foot->block_size = prev_head->header.block_size;

		ptr_head = prev_head;
	}

	void* v_next_head = v_ptr_foot+8;
	ics_free_header* next_head = (ics_free_header*) v_next_head;
	if(next_head->header.block_size%2 == 0)
	{
		coal_aft_flag = 1;
		void* v_next_foot = v_next_head+(next_head->header.block_size)-8;
		ics_footer* next_foot = (ics_footer*) v_next_foot;
		int next_block_size = next_head->header.block_size;

		if(next_head->next != NULL)
		{
			next_head->next->prev = next_head->prev;
		}
		if(next_head->prev != NULL)
		{
			next_head->prev->next = next_head->next;
		}
		if(coal_bef_flag == 0)
		{
			ptr_head->header.block_size = next_block_size+ptr_head->header.block_size-1;
		}
		else
		{
			ptr_head->header.block_size = next_block_size+ptr_head->header.block_size;
		}
		ptr_head->next = freelist_head;
		ptr_head->prev = NULL;
		freelist_head->prev = ptr_head;
		freelist_head = ptr_head;

		next_foot->block_size = ptr_head->header.block_size;
		
		ptr_foot = next_foot;
	}

	if(coal_aft_flag == 0 && coal_bef_flag == 0)
	{
		int ptr_blk_size = ptr_head->header.block_size;
		ptr_head->header.block_size = ptr_blk_size-1;
		ptr_foot->block_size = ptr_blk_size-1;

		if(freelist_head == NULL)
		{
			ptr_head->next = NULL;
			ptr_head->prev = NULL;
			freelist_head = ptr_head;
			freelist_next = ptr_head;
		}
		else
		{
			ptr_head->next = freelist_head;
			ptr_head->prev = NULL;
			freelist_head->prev = ptr_head;
			freelist_head = ptr_head;
		}
	}

	return 0;
}

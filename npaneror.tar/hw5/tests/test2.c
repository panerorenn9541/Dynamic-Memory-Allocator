#include "debug.h"
#include "icsmm.h"
#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include <stdio.h>


int main(int argc, char *argv[]) {
  ics_mem_init();

  // Tell the user about the fields
  info("Initialized heap\n");
  
  ics_freelist_print();
  
printf("Doing Malloc 64\n");
  ics_malloc(64);
  ics_freelist_print();
printf("Doing Malloc 112\n");
  void* ptr1 = ics_malloc(112);
  ics_freelist_print();
printf("Doing Malloc 48\n");
  ics_malloc(48);
  ics_freelist_print();
printf("Doing Malloc 64\n");
  void* ptr2 = ics_malloc(64);
  ics_freelist_print();
printf("Doing Malloc 16\n");
  ics_malloc(16);
  ics_freelist_print();
printf("Doing Malloc 80\n");
  void* ptr3 = ics_malloc(80);
  ics_freelist_print();
printf("Doing Malloc 3552\n");
  ics_malloc(3552);
  ics_freelist_print();
printf("Doing Free 80\n");
  ics_free(ptr3);
  ics_freelist_print();
printf("Doing Free 112\n");
  ics_free(ptr1);
  ics_freelist_print();
printf("Doing Free 64\n");
  ics_free(ptr2);
  ics_freelist_print();
printf("Doing Malloc 8\n");
  ics_freelist_print();
  ics_malloc(8);
  ics_freelist_print();
printf("Doing Malloc 80\n");
  ics_freelist_print();
  ics_malloc(80);
  ics_freelist_print();
printf("Doing Malloc 32\n");
  ics_freelist_print();
  ics_malloc(32);
  ics_freelist_print();


  ics_mem_fini();

  return EXIT_SUCCESS;
}

#ifndef HELPERS_H
#define HELPERS_H

/* Helper function declarations go here */
int first_call();

int payOffSize(int sz);

int get_counter();

void inc_counter();

void my_mem_copy(void* sou, void* des, int sz);

#endif
